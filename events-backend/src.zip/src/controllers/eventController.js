const pool = require('../config/database');
const ExcelJS = require('exceljs');
const csv = require('fast-csv');
const fs = require('fs');
const path = require('path');

const VALID_EVENT_TYPES = ['Conference', 'Workshop', 'Seminar', 'FDP', 'Webinar', 'Guest Lecture', 'Training', 'Other'];
const VALID_ROLES = ['Attendee', 'Speaker', 'Organizer', 'Resource Person', 'Chair'];
const VALID_LEVELS = ['International', 'National', 'State', 'Local', 'Institutional'];
const VALID_MODES = ['Online', 'Offline', 'Hybrid'];

const validateEventFields = (data) => {
  const errors = {};
  if (!data.event_title) errors.event_title = 'Event title is required';
  if (!data.event_type) errors.event_type = 'Event type is required';
  else if (!VALID_EVENT_TYPES.includes(data.event_type)) errors.event_type = 'Invalid event type';
  if (!data.role_at_event) errors.role_at_event = 'Role is required';
  else if (!VALID_ROLES.includes(data.role_at_event)) errors.role_at_event = 'Invalid role';
  if (!data.level) errors.level = 'Level is required';
  else if (!VALID_LEVELS.includes(data.level)) errors.level = 'Invalid level';
  if (!data.organizer) errors.organizer = 'Organizer is required';
  if (!data.mode) errors.mode = 'Mode is required';
  else if (!VALID_MODES.includes(data.mode)) errors.mode = 'Invalid mode';
  if (!data.start_date) errors.start_date = 'Start date is required';
  if (!data.end_date) errors.end_date = 'End date is required';
  if (data.start_date && data.end_date && new Date(data.end_date) < new Date(data.start_date)) {
    errors.end_date = 'End date must be on or after start date';
  }
  return errors;
};

// GET /api/events/mine
const getMine = async (req, res) => {
  const { search, status, event_type } = req.query;
  let query = 'SELECT * FROM events WHERE faculty_id = $1';
  const params = [req.user.id];
  let idx = 2;

  if (search) { query += ` AND event_title ILIKE $${idx++}`; params.push(`%${search}%`); }
  if (status) { query += ` AND status = $${idx++}`; params.push(status); }
  if (event_type) { query += ` AND event_type = $${idx++}`; params.push(event_type); }

  query += ' ORDER BY created_at DESC';

  try {
    const result = await pool.query(query, params);
    res.json(result.rows);
  } catch (err) {
    console.error('getMine error:', err);
    res.status(500).json({ error: 'Server error' });
  }
};

// POST /api/events
const createEvent = async (req, res) => {
  const { status = 'draft', ...data } = req.body;

  const certificateUrls = req.files?.certificates?.map(f => `/uploads/${f.filename}`) || [];
  const photoUrls = req.files?.photos?.map(f => `/uploads/${f.filename}`) || [];

  if (status === 'submitted') {
    const errors = validateEventFields(data);
    if (Object.keys(errors).length > 0) return res.status(400).json({ errors });
  }

  try {
    const result = await pool.query(
      `INSERT INTO events (faculty_id, event_title, event_type, role_at_event, level, organizer, venue, mode, start_date, end_date, description, certificate_urls, photo_urls, status)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)
       RETURNING *`,
      [req.user.id, data.event_title, data.event_type, data.role_at_event, data.level, data.organizer, data.venue, data.mode, data.start_date, data.end_date, data.description, certificateUrls, photoUrls, status]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error('createEvent error:', err);
    res.status(500).json({ error: 'Server error' });
  }
};

// PUT /api/events/:id
const updateEvent = async (req, res) => {
  const { id } = req.params;
  const { status = 'draft', ...data } = req.body;

  try {
    const existing = await pool.query('SELECT * FROM events WHERE id = $1 AND faculty_id = $2', [id, req.user.id]);
    if (existing.rows.length === 0) return res.status(404).json({ error: 'Event not found' });

    const existingEvent = existing.rows[0];
    const newCerts = req.files?.certificates?.map(f => `/uploads/${f.filename}`) || [];
    const newPhotos = req.files?.photos?.map(f => `/uploads/${f.filename}`) || [];

    const certificateUrls = newCerts.length > 0 ? [...existingEvent.certificate_urls, ...newCerts] : existingEvent.certificate_urls;
    const photoUrls = newPhotos.length > 0 ? [...existingEvent.photo_urls, ...newPhotos] : existingEvent.photo_urls;

    if (status === 'submitted') {
      const errors = validateEventFields(data);
      if (Object.keys(errors).length > 0) return res.status(400).json({ errors });
    }

    const result = await pool.query(
      `UPDATE events SET event_title=$1, event_type=$2, role_at_event=$3, level=$4, organizer=$5, venue=$6, mode=$7, start_date=$8, end_date=$9, description=$10, certificate_urls=$11, photo_urls=$12, status=$13, updated_at=NOW()
       WHERE id=$14 AND faculty_id=$15 RETURNING *`,
      [data.event_title, data.event_type, data.role_at_event, data.level, data.organizer, data.venue, data.mode, data.start_date, data.end_date, data.description, certificateUrls, photoUrls, status, id, req.user.id]
    );
    res.json(result.rows[0]);
  } catch (err) {
    console.error('updateEvent error:', err);
    res.status(500).json({ error: 'Server error' });
  }
};

// DELETE /api/events/:id
const deleteEvent = async (req, res) => {
  const { id } = req.params;
  try {
    const result = await pool.query('DELETE FROM events WHERE id = $1 AND faculty_id = $2 RETURNING id', [id, req.user.id]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'Event not found' });
    res.json({ message: 'Event deleted successfully' });
  } catch (err) {
    console.error('deleteEvent error:', err);
    res.status(500).json({ error: 'Server error' });
  }
};

// POST /api/events/bulk-import
const bulkImport = async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No CSV file uploaded' });

  const results = [];
  const errors = [];
  let rowNumber = 0;

  fs.createReadStream(req.file.path)
    .pipe(csv.parse({ headers: true, trim: true }))
    .on('data', (row) => {
      rowNumber++;
      const rowErrors = [];

      if (!row.event_title) rowErrors.push('event_title is required');
      if (!row.event_type) rowErrors.push('event_type is required');
      else if (!VALID_EVENT_TYPES.includes(row.event_type)) rowErrors.push(`event_type '${row.event_type}' is not a valid value`);
      if (!row.role_at_event) rowErrors.push('role_at_event is required');
      else if (!VALID_ROLES.includes(row.role_at_event)) rowErrors.push(`role_at_event '${row.role_at_event}' is not a valid value`);
      if (!row.level) rowErrors.push('level is required');
      else if (!VALID_LEVELS.includes(row.level)) rowErrors.push(`level '${row.level}' is not a valid value`);
      if (!row.organizer) rowErrors.push('organizer is required');
      if (!row.mode) rowErrors.push('mode is required');
      else if (!VALID_MODES.includes(row.mode)) rowErrors.push(`mode '${row.mode}' is not a valid value`);
      if (!row.start_date) rowErrors.push('start_date is required');
      if (!row.end_date) rowErrors.push('end_date is required');

      if (rowErrors.length > 0) {
        errors.push({ row: rowNumber, reason: rowErrors.join('; ') });
      } else {
        results.push(row);
      }
    })
    .on('end', async () => {
      let inserted = 0;
      for (const row of results) {
        try {
          await pool.query(
            `INSERT INTO events (faculty_id, event_title, event_type, role_at_event, level, organizer, venue, mode, start_date, end_date, description, certificate_urls, photo_urls, status)
             VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,'submitted')`,
            [req.user.id, row.event_title, row.event_type, row.role_at_event, row.level, row.organizer, row.venue || null, row.mode, row.start_date, row.end_date, row.description || null, [], []]
          );
          inserted++;
        } catch (err) {
          errors.push({ row: 'db', reason: err.message });
        }
      }
      fs.unlinkSync(req.file.path);
      res.json({ inserted, failed: errors.length, errors });
    })
    .on('error', (err) => {
      res.status(500).json({ error: 'Failed to parse CSV' });
    });
};

// GET /api/events/mine/export
const mineExport = async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT * FROM events WHERE faculty_id = $1 AND status = 'submitted' ORDER BY start_date DESC`,
      [req.user.id]
    );

    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet('Events');

    sheet.columns = [
      { header: 'Event Title', key: 'event_title', width: 30 },
      { header: 'Event Type', key: 'event_type', width: 15 },
      { header: 'Role at Event', key: 'role_at_event', width: 15 },
      { header: 'Level', key: 'level', width: 15 },
      { header: 'Organizer', key: 'organizer', width: 25 },
      { header: 'Venue', key: 'venue', width: 20 },
      { header: 'Mode', key: 'mode', width: 10 },
      { header: 'Start Date', key: 'start_date', width: 15 },
      { header: 'End Date', key: 'end_date', width: 15 },
      { header: 'Description', key: 'description', width: 30 },
      { header: 'Status', key: 'status', width: 10 },
      { header: 'Submitted On', key: 'created_at', width: 20 },
    ];

    sheet.getRow(1).font = { bold: true, color: { argb: 'FFFFFFFF' } };
    sheet.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF006B64' } };

    result.rows.forEach(event => {
      sheet.addRow({
        ...event,
        start_date: event.start_date ? new Date(event.start_date).toLocaleDateString('en-GB') : '',
        end_date: event.end_date ? new Date(event.end_date).toLocaleDateString('en-GB') : '',
        created_at: event.created_at ? new Date(event.created_at).toLocaleDateString('en-GB') : '',
      });
    });

    const today = new Date().toISOString().split('T')[0];
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename=my-events-${req.user.faculty_id}-${today}.xlsx`);

    await workbook.xlsx.write(res);
    res.end();
  } catch (err) {
    console.error('mineExport error:', err);
    res.status(500).json({ error: 'Server error' });
  }
};

// GET /api/events/all — admin
const getAll = async (req, res) => {
  const { search, event_type, level, mode, role_at_event, department, status, academic_year, start_date, end_date, month, has_photos, has_certificates, multi_day_only, sort_by, page = 1, limit = 20 } = req.query;

  let query = `SELECT e.*, u.name as faculty_name, u.faculty_id as faculty_code, u.department, u.designation
               FROM events e JOIN users u ON e.faculty_id = u.id WHERE 1=1`;
  const params = [];
  let idx = 1;

  if (search) {
    query += ` AND (e.event_title ILIKE $${idx} OR u.name ILIKE $${idx} OR u.faculty_id ILIKE $${idx} OR e.organizer ILIKE $${idx})`;
    params.push(`%${search}%`); idx++;
  }
  if (event_type) {
    const types = event_type.split(',');
    query += ` AND e.event_type = ANY($${idx++})`;
    params.push(types);
  }
  if (level) {
    const levels = level.split(',');
    query += ` AND e.level = ANY($${idx++})`;
    params.push(levels);
  }
  if (mode) {
    const modes = mode.split(',');
    query += ` AND e.mode = ANY($${idx++})`;
    params.push(modes);
  }
  if (role_at_event) {
    const roles = role_at_event.split(',');
    query += ` AND e.role_at_event = ANY($${idx++})`;
    params.push(roles);
  }
  if (department) {
    const depts = department.split(',');
    query += ` AND u.department = ANY($${idx++})`;
    params.push(depts);
  }
  if (status) { query += ` AND e.status = $${idx++}`; params.push(status); }
  if (academic_year && !start_date) {
    const [startY] = academic_year.split('-');
    query += ` AND e.start_date >= $${idx++} AND e.start_date <= $${idx++}`;
    params.push(`${startY}-07-01`);
    params.push(`${parseInt(startY) + 1}-06-30`);
  }
  if (start_date) { query += ` AND e.start_date >= $${idx++}`; params.push(start_date); }
  if (end_date) { query += ` AND e.end_date <= $${idx++}`; params.push(end_date); }
  if (month) { query += ` AND EXTRACT(MONTH FROM e.start_date) = $${idx++}`; params.push(month); }
  if (has_photos === 'true') { query += ` AND array_length(e.photo_urls, 1) > 0`; }
  if (has_certificates === 'true') { query += ` AND array_length(e.certificate_urls, 1) > 0`; }
  if (multi_day_only === 'true') { query += ` AND e.end_date > e.start_date`; }

  const sortMap = {
    date_asc: 'e.start_date ASC',
    faculty_name: 'u.name ASC',
    event_title: 'e.event_title ASC',
    level: `CASE e.level WHEN 'International' THEN 1 WHEN 'National' THEN 2 WHEN 'State' THEN 3 WHEN 'Local' THEN 4 ELSE 5 END`
  };
  query += ` ORDER BY ${sortMap[sort_by] || 'e.created_at DESC'}`;

  try {
    const countResult = await pool.query(`SELECT COUNT(*) FROM (${query}) as sub`, params);
    const total = parseInt(countResult.rows[0].count);

    const offset = (parseInt(page) - 1) * parseInt(limit);
    query += ` LIMIT $${idx++} OFFSET $${idx++}`;
    params.push(parseInt(limit), offset);

    const result = await pool.query(query, params);
    res.json({ data: result.rows, total, page: parseInt(page), limit: parseInt(limit) });
  } catch (err) {
    console.error('getAll error:', err);
    res.status(500).json({ error: 'Server error' });
  }
};

// GET /api/events/export — admin
const adminExport = async (req, res) => {
  const { search, event_type, level, mode, role_at_event, department, status, academic_year, start_date, end_date } = req.query;

  let query = `SELECT e.*, u.name as faculty_name, u.faculty_id as faculty_code, u.department, u.designation
               FROM events e JOIN users u ON e.faculty_id = u.id WHERE 1=1`;
  const params = [];
  let idx = 1;

  if (search) { query += ` AND (e.event_title ILIKE $${idx} OR u.name ILIKE $${idx} OR u.faculty_id ILIKE $${idx} OR e.organizer ILIKE $${idx})`; params.push(`%${search}%`); idx++; }
  if (event_type) { query += ` AND e.event_type = ANY($${idx++})`; params.push(event_type.split(',')); }
  if (level) { query += ` AND e.level = ANY($${idx++})`; params.push(level.split(',')); }
  if (mode) { query += ` AND e.mode = ANY($${idx++})`; params.push(mode.split(',')); }
  if (role_at_event) { query += ` AND e.role_at_event = ANY($${idx++})`; params.push(role_at_event.split(',')); }
  if (department) { query += ` AND u.department = ANY($${idx++})`; params.push(department.split(',')); }
  if (status) { query += ` AND e.status = $${idx++}`; params.push(status); }
  if (academic_year && !start_date) {
    const [startY] = academic_year.split('-');
    query += ` AND e.start_date >= $${idx++} AND e.start_date <= $${idx++}`;
    params.push(`${startY}-07-01`, `${parseInt(startY) + 1}-06-30`);
  }
  if (start_date) { query += ` AND e.start_date >= $${idx++}`; params.push(start_date); }
  if (end_date) { query += ` AND e.end_date <= $${idx++}`; params.push(end_date); }

  query += ' ORDER BY e.created_at DESC';

  try {
    const result = await pool.query(query, params);

    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet('Events');

    sheet.columns = [
      { header: 'Faculty Name', key: 'faculty_name', width: 20 },
      { header: 'Faculty ID', key: 'faculty_code', width: 15 },
      { header: 'Department', key: 'department', width: 20 },
      { header: 'Designation', key: 'designation', width: 20 },
      { header: 'Event Title', key: 'event_title', width: 30 },
      { header: 'Event Type', key: 'event_type', width: 15 },
      { header: 'Role at Event', key: 'role_at_event', width: 15 },
      { header: 'Level', key: 'level', width: 15 },
      { header: 'Organizer', key: 'organizer', width: 25 },
      { header: 'Venue', key: 'venue', width: 20 },
      { header: 'Mode', key: 'mode', width: 10 },
      { header: 'Start Date', key: 'start_date', width: 15 },
      { header: 'End Date', key: 'end_date', width: 15 },
      { header: 'Description', key: 'description', width: 30 },
      { header: 'Status', key: 'status', width: 10 },
      { header: 'Submitted On', key: 'created_at', width: 20 },
    ];

    sheet.getRow(1).font = { bold: true, color: { argb: 'FFFFFFFF' } };
    sheet.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF006B64' } };

    result.rows.forEach(event => {
      sheet.addRow({
        ...event,
        start_date: event.start_date ? new Date(event.start_date).toLocaleDateString('en-GB') : '',
        end_date: event.end_date ? new Date(event.end_date).toLocaleDateString('en-GB') : '',
        created_at: event.created_at ? new Date(event.created_at).toLocaleDateString('en-GB') : '',
      });
    });

    const today = new Date().toISOString().split('T')[0];
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename=events-export-${today}.xlsx`);

    await workbook.xlsx.write(res);
    res.end();
  } catch (err) {
    console.error('adminExport error:', err);
    res.status(500).json({ error: 'Server error' });
  }
};

module.exports = { getMine, createEvent, updateEvent, deleteEvent, bulkImport, mineExport, getAll, adminExport };