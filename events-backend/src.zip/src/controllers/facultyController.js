const pool = require('../config/database');
const bcrypt = require('bcryptjs');

const listFaculty = async (req, res) => {
  const { search, department } = req.query;

  let query = `SELECT u.id, u.faculty_id, u.name, u.email, u.department, u.designation, u.created_at,
               (SELECT COUNT(*) FROM events e WHERE e.faculty_id = u.id) as total_events
               FROM users u WHERE u.role = 'faculty'`;
  const params = [];
  let idx = 1;

  if (search) {
    query += ` AND (u.name ILIKE $${idx} OR u.faculty_id ILIKE $${idx})`;
    params.push(`%${search}%`); idx++;
  }
  if (department) {
    query += ` AND u.department = $${idx++}`;
    params.push(department);
  }

  query += ' ORDER BY u.created_at DESC';

  try {
    const result = await pool.query(query, params);
    res.json(result.rows);
  } catch (err) {
    console.error('listFaculty error:', err);
    res.status(500).json({ error: 'Server error' });
  }
};

const createFaculty = async (req, res) => {
  const { name, faculty_id, email, department, designation, password } = req.body;

  if (!name || !faculty_id || !email || !department || !designation || !password) {
    return res.status(400).json({ error: 'All fields are required' });
  }

  try {
    const existingId = await pool.query('SELECT id FROM users WHERE faculty_id = $1', [faculty_id]);
    if (existingId.rows.length > 0) return res.status(400).json({ error: 'Faculty ID already registered' });

    const existingEmail = await pool.query('SELECT id FROM users WHERE email = $1', [email]);
    if (existingEmail.rows.length > 0) return res.status(400).json({ error: 'Email already in use' });

    const hashedPassword = await bcrypt.hash(password, 10);

    const result = await pool.query(
      `INSERT INTO users (name, faculty_id, email, password, department, designation, role)
       VALUES ($1, $2, $3, $4, $5, $6, 'faculty')
       RETURNING id, faculty_id, name, email, department, designation, role, created_at`,
      [name, faculty_id, email, hashedPassword, department, designation]
    );

    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error('createFaculty error:', err);
    res.status(500).json({ error: 'Server error' });
  }
};

const updateProfile = async (req, res) => {
  const { name, department, designation } = req.body;
  try {
    const result = await pool.query(
      `UPDATE users SET name=$1, department=$2, designation=$3, updated_at=NOW()
       WHERE id=$4 RETURNING id, faculty_id, name, email, department, designation, role`,
      [name, department, designation, req.user.id]
    );
    res.json(result.rows[0]);
  } catch (err) {
    console.error('updateProfile error:', err);
    res.status(500).json({ error: 'Server error' });
  }
};

const changePassword = async (req, res) => {
  const { current_password, new_password, confirm_password } = req.body;

  if (!current_password || !new_password || !confirm_password) {
    return res.status(400).json({ error: 'All fields are required' });
  }
  if (new_password !== confirm_password) {
    return res.status(400).json({ error: 'New passwords do not match' });
  }

  try {
    const result = await pool.query('SELECT password FROM users WHERE id = $1', [req.user.id]);
    const user = result.rows[0];

    const isMatch = await bcrypt.compare(current_password, user.password);
    if (!isMatch) return res.status(400).json({ error: 'Current password is incorrect' });

    const hashed = await bcrypt.hash(new_password, 10);
    await pool.query('UPDATE users SET password=$1, updated_at=NOW() WHERE id=$2', [hashed, req.user.id]);

    res.json({ message: 'Password updated successfully' });
  } catch (err) {
    console.error('changePassword error:', err);
    res.status(500).json({ error: 'Server error' });
  }
};

module.exports = { listFaculty, createFaculty, updateProfile, changePassword };