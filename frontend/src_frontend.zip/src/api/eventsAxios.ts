import axios from 'axios'

const eventsAxios = axios.create({
  baseURL: (import.meta.env.VITE_EVENTS_ORIGIN ?? '') + '/api/events',
})

eventsAxios.interceptors.request.use((config) => {
  const token = localStorage.getItem('token')
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

eventsAxios.interceptors.response.use(
  (res) => res,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token')
      localStorage.removeItem('user')
      window.location.href = '/login'
    }
    return Promise.reject(error)
  }
)

export default eventsAxios